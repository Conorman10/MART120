function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
circle(200,50,80)
line (200,90,200,110)
  rect(180,110,40,150)
  line(180,130,130,200)
  line(220,130,270,200)
  line(190,260,170,380)
  line(210,260,230,380)
  triangle(150,380,173,360,170,380)
  triangle(230,380,227,360,250,380)
  ellipse (185,40,25,14)
  ellipse(215,40,25,14)
  circle(215,40,14)
  circle(185,40,14)
  point(185,40)
  point(215,40)
  line(180,60,200,80)
  line(200,80,220,60)
  line(175,30,197,25)
  line(203,25,225,30)
  textSize(27)
  text ('ShapeMe',26,50)
  textSize (15)
  text ('By Conor Manley',27,70)
  
  
  
}